package ListaN2;

import java.util.Scanner;

public class Ex22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int c;
	Scanner entrada = new Scanner (System.in);	
		
		System.out.println("Informe o valor de N");
		int n = entrada.nextInt();
		
		for(c = 0; c<=n; c++ ) {
			
			System.out.println(c);
		}
		
		
		
		
		
	entrada.close();	
	}

}
