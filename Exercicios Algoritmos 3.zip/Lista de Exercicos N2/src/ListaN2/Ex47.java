package ListaN2;

public class Ex47 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
