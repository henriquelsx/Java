package ListaN2;

import java.util.Scanner;

public class Ex10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner entrada = new Scanner (System.in);

int numero = 0, cont = 1;

while (numero >= 0) {
System.out.println("Insira um n�mero: ");
	numero = entrada.nextInt();
cont++;	
}
		
	System.out.println("N�meros digitados : "+cont);	
		
		
		
		
		
		
		
		
		
		
		
		
		
entrada.close();		
	}

}
