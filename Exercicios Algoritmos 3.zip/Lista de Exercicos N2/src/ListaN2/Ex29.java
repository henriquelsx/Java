package ListaN2;

public class Ex29 {
	public static void main(String[] args) {
		
		int n ,c ;
		
		for(n=1; n <=10; n++)
		{
			System.out.println("****** TABUADA DE " +n+ " ******\n");
			
			for(c = 0; c<=10; c++)
			{
				System.out.println(n+ " X " + c + " = " + (n*c));
				
			}
			
			System.out.println(" \n\n");
		}
		
		
		
		
		
		
		
		
	}

}
