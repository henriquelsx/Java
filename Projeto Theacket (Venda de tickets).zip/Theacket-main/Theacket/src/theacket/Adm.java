package theacket;

public class Adm {
    public static int[] ingressosPeca = new int[2];
    public static int[] poltronasSess = new int[6];
    public static double[] lucroPeca = new double[2];
    public static double[] lucroSess = new double[6];
}
