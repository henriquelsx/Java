package listaN1;

public class Ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.out.println(" � preciso fazer todos exerc�cios para aprender algoritmos!");
		

	}

}
